<?php

$host="localhost";

$user="root";

$password="";

$databasename="cam";

$con=mysqli_connect($host,$user,$password,$databasename);

?>
