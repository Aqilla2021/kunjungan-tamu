<?php error_reporting(0);
  session_destroy();
  echo "<script>alert('anda berhasil logout '); window.location = 'index.php'</script>";
?>
