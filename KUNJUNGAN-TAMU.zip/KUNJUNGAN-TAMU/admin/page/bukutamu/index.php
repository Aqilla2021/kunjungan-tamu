<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Kunjungan Tamu
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Kunjungan Tamu</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Main row -->
          <div class="row">
            <!-- Left col -->
            <section class="col-lg-12 connectedSortable">

               <!-- TO DO List -->   <div class="box-footer clearfix no-border">
                  <a href="?page=page/bukutamu/tambah" class="btn btn-sm btn-default pull-right"><i class="fa fa-plus"></i> Tambah Kunjungan Tamu</a>
                </div>
              <div class="box box-primary">
                <div class="box-header">
                  <i class="ion ion-clipboard"></i>
                  <h3 class="box-title">Data Kunjungan Tamu</h3>
                  <div class="box-tools pull-right">
                  <form action='?page=page/bukutamu/index' method="POST">
                   <div class="input-group" style="width: 230px;">
                      <input type="text" name="qcari" class="form-control input-sm pull-right" placeholder="Cari Nama">
                      <div class="input-group-btn">
                        <button type="submit" class="btn btn-sm btn-default tooltips" data-placement="bottom" data-toggle="tooltip" title="Cari Data"><i class="fa fa-search"></i></button>
                        <a href="?page=page/bukutamu/index" class="btn btn-sm btn-success tooltips" data-placement="bottom" data-toggle="tooltip" title="Refresh"><i class="fa fa-refresh"></i></a>
                      </div>
                    </div>
                    </form>
                  </div> 
                </div><!-- /.box-header -->
                
                <div class="box-body">
                <!-- <form action='Kunjungan Tamu.php' method="POST">
          
         <input type='text' class="form-control" style="margin-bottom: 4px;" name='qcari' placeholder='Cari berdasarkan User ID dan Username' required /> 
           <input type='submit' value='Cari Data' class="btn btn-sm btn-primary" /> <a href='Kunjungan Tamu.php' class="btn btn-sm btn-success" >Refresh</i></a>
            </div>
            </form>--><?php
                    $query1="select * from bukutamu";
                    
                    if(isset($_POST['qcari'])){
                 $qcari=$_POST['qcari'];
                 $query1="SELECT * FROM  bukutamu 
                 where  nama like '%$qcari%' ";
                    }
                    $tampil=$koneksi->query( $query1);
                    ?>
                  
                  <table id="example" class="table table-responsive table-hover table-bordered">
                  <thead>
                      <tr>
                        <th><center>No </center></th>
                        <th><center>Nama</center></th>
                        <th><center>KTP </center></th>
                        <th><center>Tujuan </center></th>
                        <th><center>Dari </center></th>
                        <th><center>Aksi</center></th>
                      </tr>
                  </thead>
                   
                    <tbody>
                       <?php 
                     $no=0;
                     while($data=mysqli_fetch_array($tampil))
                    { $no++; ?>
                    <tr>
                    <td><center><?= $no;?></center></td>
                    <td><center><?= $data['nama']; ?></center></td>
                    <td><center><img src="images/ktp/<?= $data['foto']; ?>" class="img-b" height="200" width="200" /></center></td>
                    <td><center><?= $data['tujuan']; ?></center></td>
                    <td><center><?= $data['instansi']; ?></a></center></td>
                    <td><center><?= tgl_indonesia($data['tanggal']); ?> <?= $data['jam']; ?></center></td>
                    
                    <td><center><div id="thanks"><a class="btn btn-sm btn-success" data-placement="bottom" href="?page=page/jadwal/tambah&id=<?= $data['id_bukutamu']; ?>">Kirim Ke Sekretaris</a>

                      <a class="btn btn-sm btn-primary" data-placement="bottom" data-toggle="tooltip" title="Edit Kunjungan Tamu" href="?page=page/bukutamu/edit&id=<?= $data['id_bukutamu']; ?>"><span class="glyphicon glyphicon-edit"></span></a>  
                        <a onclick="return confirm ('Yakin hapus .?');" class="btn btn-sm btn-danger tooltips" data-placement="bottom" data-toggle="tooltip" title="Hapus Kunjungan Tamu" href="?page=page/bukutamu/hapus&id=<?= $data['id_bukutamu']; ?>"><span class="glyphicon glyphicon-trash"></a></center></td></tr>

                        <?php   
              } 
              ?>
            </div>
                 
                   </tbody>
                   </table>
                </div><!-- /.box-body -->
             
              </div><!-- /.box -->

            </section><!-- /.Left col -->
          </div><!-- /.row (main row) -->

        </section><!-- /.content -->
      </div>