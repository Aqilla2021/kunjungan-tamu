
  
<?php 



  $foto   = $_FILES['image']['name'];
$tujuan       = $_POST['tujuan'];
        $instansi       = $_POST['instansi'];
        $nama       = $_POST['nama'];
  if (empty($foto)){
    $koneksi->query("UPDATE bukutamu SET 
                    nama     = '$nama',
                    instansi     = '$instansi',
                    tujuan = '$tujuan'
                    WHERE id_bukutamu = '$_POST[id_bukutamu]'");
}elsei{

    $hapus= $koneksi->query("select * from bukutamu where id_bukutamu='$_GET[id]'");
    $tanggal_foto=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_foto['foto'];
    $hapus_foto="images/ktp/$lokasi";
    unlink($hapus_foto);
    move_uploaded_file($_FILES['image']['tmp_name'],'images/ktp/'.$foto);
    $koneksi->query("UPDATE bukutamu SET 
                    nama     = '$nama',
                    instansi     = '$instansi',
                    tujuan = '$tujuan',
                    foto  = '$foto'
                    WHERE id_bukutamu= '$_POST[id_bukutamu]'");
 }
echo"";
    


 ?>