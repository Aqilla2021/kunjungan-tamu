<?php
        if(empty($_POST['nama']) or empty($_POST['tujuan']) or empty($_POST['instansi'])){
            echo"<script>alert('Nama, Tujuan dan Instansi tidak boleh kosong!!!'); window.location = '?page=page/bukutamu/tambah'</script>";
  
        }else{
        define('UPLOAD_DIR', 'images/ktp/');
    
        
    
        //menangkap variabel
        $img        = $_POST['image'];
        $tujuan       = $_POST['tujuan'];
        $instansi       = $_POST['instansi'];
        $nama       = $_POST['nama'];
    
        $img        = str_replace('data:image/jpeg;base64,', '', $img);
        $img        = str_replace(' ', '+', $img);
    
        //resource gambar diubah dari encode
        $data       = base64_decode($img);
    
        //menamai file, file dinamai secara random dengan unik
        $file       = uniqid() . '.png';
        
        //memindahkan file ke folder upload
        file_put_contents(UPLOAD_DIR.$file, $data);
    
        //memasukkan data ke dalam tabel biodata
        $koneksi->query( "insert into bukutamu set 
                    nama     = '$nama',
                tujuan='$tujuan',
                instansi='$instansi',
                tanggal='$tgl_sekarang',
                jam='$jam_sekarang',
                 foto='$file'");
    }
    ?>