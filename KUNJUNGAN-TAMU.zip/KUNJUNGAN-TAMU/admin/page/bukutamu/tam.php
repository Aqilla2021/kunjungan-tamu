<section class="content-header">
          <h1>
            Tambah
            <small>Buku Tamu</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="?page=page/home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Buku Tamu</li>
          </ol>
        </section>

        <!-- Content Header (Page header) -->
        <section class="content-header">
          <div class="content-wrapper">
 <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <!-- form  -->
                        <form  class="form-horizontal style-form"  id="form">
                            <div class="form-group">
                                <label>name</label>
                                <input type="text" class="form-control" name="tujuan" id="tujuan" required>
                            </div>
                             <div class="form-group">
                                <label>name</label>
                                <input type="text" class="form-control" name="instansi" id="instansi" required>
                            </div>

                            <!-- kamera webcam akan ditampilkan di dalam id="my_camera" -->
                            <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Foto KTP</label>
                              <div class="col-sm-8">
                                  <div id="my_camera">
                            </div>
                              </div>
                          </div>
                            <br>
                            <hr>
                            <button type="submit" class="tombol-simpan btn btn-primary">Register</button>
                        </form>  
                  </div>
               
            </section><!-- /.Left col -->
          </div>
    <!-- jquery  -->
    <script src="https://code.jquery.com/jquery-3.5.1.js"
        integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"
        integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous">
    </script>
    <!-- bootstrap js  -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"
        integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous">
    </script>
    <!-- webcamjs  -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.js"></script>
    <script language="JavaScript">
        // menampilkan kamera dengan menentukan ukuran, format dan kualitas 
        Webcam.set({
            width: 320,
            height: 240,
            image_format: 'jpeg',
            jpeg_quality: 90
        });

        //menampilkan webcam di dalam file html dengan id my_camera
        Webcam.attach('#my_camera');

    </script>

    <script type="text/javascript">
        // saat dokumen selesai dibuat jalankan fungsi update
        $(document).ready(function () {
            update();
        });

        // jalankan aksi saat tombol register disubmit
        $(".tombol-simpan").click(function () {
            event.preventDefault();

            // membuat variabel image
            var image = '';

            //mengambil data uername dari form di atas dengan id name
            var instansi = $('#instansi').val();

            //mengambil data email dari form di atas dengan id email
            var tujuan = $('#tujuan').val();

            //memasukkan data gambar ke dalam variabel image
            Webcam.snap(function (data_uri) {
                image = data_uri;
            });

            //mengirimkan data ke file action.php dengan teknik ajax
            $.ajax({
                url: '?page=page/bukutamu/simpan',
                type: 'POST',
                data: {
                    instansi: instansi,
                    tujuan: tujuan,
                    image: image
                },
                success: function () {
                    alert('input data berhasil');
                    // menjalankan fungsi update setelah kirim data selesai dilakukan 
                    update()
                }
            })
        });


        //fungsi update untuk menampilkan data
        // function update() {
        //     $.ajax({
        //         url: 'data.php',
        //         type: 'get',
        //         success: function (data) {
        //             $('#data').html(data);
        //         }
        //     });
        // }

    </script>
      </section><!-- /.Left col -->
          </div>