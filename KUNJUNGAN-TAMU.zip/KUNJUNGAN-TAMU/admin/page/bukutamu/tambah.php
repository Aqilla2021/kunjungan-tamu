  
<script type="text/javascript" src="../webcam.min.js"></script>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Tambah
            <small>Kunjungan Tamu</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="?page=page/home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Kunjungan Tamu</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Main row -->
          <div class="row">
            <!-- Left col -->
            <section class="col-lg-12 connectedSortable">

              <!-- TO DO List -->
              <div class="box box-primary">
                <div class="box-header">
                  <i class="ion ion-clipboard"></i>
                  <h3 class="box-title">Tambah Data Kunjungan Tamu</h3>
                  <!-- <div class="box-tools pull-right">
                    <ul class="pagination pagination-sm inline">
                      <li><a href="#">&laquo;</a></li>
                       <li><a href="#">1</a></li>
                      <li><a href="#">2</a></li>
                      <li><a href="#">3</a></li>
                       <li><a href="#">&raquo;</a></li>
                    </ul>
                  </div> -->
                </div><!-- /.box-header -->
                <div class="box-body">
                  <div class="form-panel">
                      <form class="form-horizontal style-form" id="form">
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Foto KTP</label>
                              <div class="col-sm-8">
                                  <div id="my_camera">
                            </div>
                              </div>
                          </div>
                           <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Nama</label>
                              <div class="col-sm-8">
                                  <input name="nama" type="text" id="nama" class="form-control" placeholder="" autocomplete="off" required />
                                  <!--<span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>-->
                              </div>
                          </div> 
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Tujuan Kunjungan</label>
                              <div class="col-sm-8">
                                  <input name="tujuan" type="text" id="tujuan" class="form-control" placeholder="" autocomplete="off" required />
                                  <!--<span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>-->
                              </div>
                          </div> 
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Dari</label>
                              <div class="col-sm-8">
                                  <input name="instansi" type="text" id="instansi" class="form-control" placeholder=""  autocomplete="off" required />
                                  <!--<span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>-->
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label"></label>
                              <div class="col-sm-10">
                                   <button type="submit" class="tombol-simpan btn btn-primary">Simpan</button>&nbsp;
                                <a href="?page=page/bukutamu/index" class="btn btn-sm btn-danger">Batal </a>
                              </div>
                          </div>
                      </form>
                  </div>
                </div><!-- /.box-body -->
                <!-- <div class="box-footer clearfix no-border">
                  <a href="#" class="btn btn-default pull-right"><i class="fa fa-plus"></i> Tambah Admin</a>
                </div> -->
              </div><!-- /.box -->

            </section><!-- /.Left col -->
          </div>

   <script src="https://code.jquery.com/jquery-3.5.1.js"
        integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"
        integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous">
    </script>
    <!-- bootstrap js  -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"
        integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous">
    </script>
    <!-- webcamjs  -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.js"></script>
    <script language="JavaScript">

        // menampilkan kamera dengan menentukan ukuran, format dan kualitas 
        Webcam.set({
            width: 420,
            height: 340,
            image_format: 'jpeg',
            jpeg_quality: 90
        });

        //menampilkan webcam di dalam file html dengan id my_camera
        Webcam.attach('#my_camera');

    </script>

    <script type="text/javascript">
        // saat dokumen selesai dibuat jalankan fungsi update
        $(document).ready(function () {
            update();
        });

        // jalankan aksi saat tombol register disubmit
        $(".tombol-simpan").click(function () {
            event.preventDefault();

            // membuat variabel image
            var image = '';

            //mengambil data uername dari form di atas dengan id name
            var instansi = $('#instansi').val();
            var nama = $('#nama').val();

            //mengambil data email dari form di atas dengan id email
            var tujuan = $('#tujuan').val();

            //memasukkan data gambar ke dalam variabel image
            Webcam.snap(function (data_uri) {
                image = data_uri;
            });

            //mengirimkan data ke file action.php dengan teknik ajax
            $.ajax({
                url: '?page=page/bukutamu/simpan',
                type: 'POST',
                data: {
                    nama: nama,
                    instansi: instansi,
                    tujuan: tujuan,
                    image: image
                },
                success: function () {
                    alert('input data berhasil');
                    window.location = '?page=page/bukutamu/index';
                    update()
                }
            })
        });


        //fungsi update untuk menampilkan data
        // function update() {
        //     $.ajax({
        //         url: 'data.php',
        //         type: 'get',
        //         success: function (data) {
        //             $('#data').html(data);
        //         }
        //     });
        // }

    </script>