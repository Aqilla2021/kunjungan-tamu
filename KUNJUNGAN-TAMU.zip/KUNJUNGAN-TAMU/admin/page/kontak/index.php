 <?php  $query1="select * from kontak where id_kontak='1'";
$tampil=$koneksi->query( $query1);
$data=mysqli_fetch_array($tampil)
?> 
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Data
            <small>Kontak Kami</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="?page=page/home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Kontak Kami</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Main row -->
          <div class="row">
            <!-- Left col -->
            <section class="col-lg-12 connectedSortable">

              <!-- TO DO List -->
              <div class="box box-primary">
                <div class="box-header">
                  <i class="ion ion-clipboard"></i>
                  <h3 class="box-title">Update Data Kontak Kami</h3>
                  <!-- <div class="box-tools pull-right">
                    <ul class="pagination pagination-sm inline">
                      <li><a href="#">&laquo;</a></li>
                      <li><a href="#">1</a></li>
                      <li><a href="#">2</a></li>
                      <li><a href="#">3</a></li>
                       <li><a href="#">&raquo;</a></li>
                    </ul>
                  </div> -->
                </div><!-- /.box-header -->
                <div class="box-body">
                  <div class="form-panel">
                      <form class="form-horizontal style-form" method="post" action="?page=page/kontak/simpan"  enctype="multipart/form-data">
                           <input name="id" type="hidden"  class="form-control" value="<?= $data['id_kontak'];?>" autocomplete="off" required />
                           <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Nama Kontak</label>
                              <div class="col-sm-8">
                                  <input name="nama" type="text"  class="form-control" value="<?= $data['nama'];?>" autocomplete="off" required />
                                  <!--<span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>-->
                              </div>
                          </div> 
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Email</label>
                              <div class="col-sm-8">
                                  <input name="email" type="text"  class="form-control" value="<?= $data['email'];?>" autocomplete="off" required />
                                  <!--<span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>-->
                              </div>
                          </div> 
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Telpon</label>
                              <div class="col-sm-8">
                                  <input name="tlp" type="text"  class="form-control" value="<?= $data['tlp'];?>" autocomplete="off" required />
                                  <!--<span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>-->
                              </div>
                          </div> 
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Alamat</label>
                              <div class="col-sm-8">
                                <textarea name="alamat" type="text"  class="form-control"><?= $data['alamat'];?></textarea>
                                
                                  <!--<span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>-->
                              </div>
                          </div> 
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Maps</label>
                              <div class="col-sm-8">
                                <textarea name="maps" type="text"  class="form-control"><?= $data['maps'];?></textarea>
                                
                                  <!--<span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>-->
                              </div>
                          </div> 
                           <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Logo</label>
                              <div class="col-sm-8">
                                <img src="../images/kontak/<?= $data['logo'];?>" width="200px">
                                  <input name="foto" type="file"  class="form-control" >
                                  <!--<span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>-->
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label"></label>
                              <div class="col-sm-10">
                                   <input type="submit" name="simpan" value="Edit" class="tombol-simpan btn btn-primary">&nbsp;
                                <a  href="?page=page/kontak/index" class="btn btn-sm btn-danger">Batal </a>
                              </div>
                          </div>
                      </form>
                  </div>
                </div><!-- /.box-body -->
                <!-- <div class="box-footer clearfix no-border">
                  <a href="#" class="btn btn-default pull-right"><i class="fa fa-plus"></i> Edit kontak</a>
                </div> -->
              </div><!-- /.box -->

            </section><!-- /.Left col -->
          </div>
