
 <?php 

if (isset($_POST['simpan'])){

  $foto   = $_FILES['foto']['name'];
    $nama=addslashes($_POST['nama']);
  $email=addslashes($_POST['email']);
  $tlp=addslashes($_POST['tlp']);
  $alamat=addslashes($_POST['alamat']);
  $maps=addslashes($_POST['maps']);
  if (empty($foto)){
    $koneksi->query("UPDATE kontak SET 
                     nama     = '$nama',
                    email     = '$email',
                    tlp     = '$tlp',
                    alamat     = '$alamat',
                    maps     = '$maps'
                    WHERE id_kontak = '$_POST[id]'");
}else{


    $hapus= $koneksi->query("select * from kontak where id_kontak='$_POST[id]'");
    $tanggal_foto=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_foto['logo'];
    $hapus_foto="../images/kontak/$lokasi";
    unlink($hapus_foto);
    $koneksi->query("UPDATE kontak SET  nama     = '$nama',
                    email     = '$email',
                    tlp     = '$tlp',
                    alamat     = '$alamat',
                    maps     = '$maps',
                    logo  = '$foto'
                    WHERE id_kontak= '$_POST[id]'");
    move_uploaded_file($_FILES['foto']['tmp_name'],'../images/kontak/'.$foto);
  }
echo"<script>alert('Data Berhasil di Ubah!!!'); window.location = '?page=page/kontak/index'</script>";
    }



 ?>