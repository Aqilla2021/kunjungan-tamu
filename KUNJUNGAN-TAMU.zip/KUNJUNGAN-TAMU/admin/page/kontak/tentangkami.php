 <?php  $query1="select * from kontak where id_kontak='1'";
$tampil=$koneksi->query( $query1);
$data=mysqli_fetch_array($tampil)
?> 
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Data
            <small>Tentang Kami</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="?page=page/home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Tentang Kami</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Main row -->
          <div class="row">
            <!-- Left col -->
            <section class="col-lg-12 connectedSortable">

              <!-- TO DO List -->
              <div class="box box-primary">
                <div class="box-header">
                  <i class="ion ion-clipboard"></i>
                  <h3 class="box-title">Update Data Tentang Kami</h3>
                  <!-- <div class="box-tools pull-right">
                    <ul class="pagination pagination-sm inline">
                      <li><a href="#">&laquo;</a></li>
                      <li><a href="#">1</a></li>
                      <li><a href="#">2</a></li>
                      <li><a href="#">3</a></li>
                       <li><a href="#">&raquo;</a></li>
                    </ul>
                  </div> -->

  <script src="ckeditor/ckeditor.js"></script>
    
            
                </div><!-- /.box-header -->
                <div class="box-body">
                  <div class="form-panel">
                      <form class="form-horizontal style-form" action="" method="post" enctype="multipart/form-data">
                           <input name="id" type="hidden"  class="form-control" value="<?= $data['id_kontak'];?>" autocomplete="off" required />
                           
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Tentang Kami</label>
                              <div class="col-sm-8">
                                <textarea name="tentangkami" id="idsas" type="text"  class="form-control"><?= $data['tentangkami'];?></textarea>
                                
                                  <!--<span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>-->
                              </div>
                          </div> 
                          <script type="text/javascript">
      CKEDITOR.replace( 'idsas',{height: 300} );
    </script>
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label"></label>
                              <div class="col-sm-10">
                                   <input type="submit" name="simpan" value="Update" class="tombol-simpan btn btn-primary">&nbsp;
                               </div>
                          </div>
                      </form>
                  </div>
                </div><!-- /.box-body -->
                <!-- <div class="box-footer clearfix no-border">
                  <a href="#" class="btn btn-default pull-right"><i class="fa fa-plus"></i> Edit kontak</a>
                </div> -->
              </div><!-- /.box -->

            </section><!-- /.Left col -->
          </div>
         
<?php 

if (isset($_POST['simpan'])){

  $nama=addslashes($_POST['tentangkami']);
  
    $koneksi->query("UPDATE kontak SET 
                    tentangkami     = '$nama'
                    WHERE id_kontak = '$_POST[id]'");

echo"<script>alert('Data Berhasil di Ubah!!!'); window.location = '?page=page/kontak/tentangkami'</script>";
    }



 ?>